/**
\file customflags.h

Custom polyflags (reuse existing ones)
*/
