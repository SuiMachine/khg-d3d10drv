/**
\file misc.h
*/

namespace Misc
{
	int getFov(int defaultFOV, int resX, int resY);
}